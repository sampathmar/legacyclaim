# LegacyClaim — Vercel Deployment Guide

Frontend + backend in one Vercel project. No Render. No separate server.

---

## Project structure after migration

```
legacyclaim-vercel/              ← root of your Vercel project
│
├── index.html                   ← frontend (served by Vercel CDN)
├── dashboard.html
├── styles.css
├── app.js
├── config.js                    ← API URL config (relative in prod)
│
├── assets/
│   └── logo.png                 ← place your logo here
│
├── api/                         ← Vercel Functions (your backend)
│   ├── health.js                ← GET /api/health
│   └── v1/
│       ├── auth.js              ← /api/v1/auth/*
│       ├── cases.js             ← /api/v1/cases/*
│       ├── dashboard.js         ← /api/v1/dashboard/*
│       ├── discovery.js         ← /api/v1/discovery/*
│       ├── documents.js         ← /api/v1/documents/*
│       ├── invoices.js          ← /api/v1/invoices/*
│       ├── messages.js          ← /api/v1/messages/*
│       ├── partners.js          ← /api/v1/partners/*
│       └── features/
│           └── index.js         ← /api/v1/features/*
│
├── lib/                         ← shared backend code (not deployed directly)
│   ├── createApp.js             ← Express factory used by all Functions
│   ├── config/
│   │   ├── logger.js
│   │   └── supabase.js
│   ├── controllers/             ← all 9 controllers (unchanged)
│   ├── middleware/              ← auth, upload, validate, errorHandler
│   ├── services/                ← aiDiscoveryEngine, storageService, workflowEngine
│   └── utils/                  ← caseId, jwt, response
│
├── vercel.json                  ← route rewrites
├── package.json
├── .env.example
└── .gitignore
```

---

## Step 1 — Push to GitHub

```bash
cd legacyclaim-vercel

git init
git add .
git commit -m "LegacyClaim — Vercel full-stack"

# Create repo on github.com, then:
git remote add origin https://github.com/YOUR_USERNAME/legacyclaim.git
git branch -M main
git push -u origin main
```

---

## Step 2 — Import project on Vercel

1. Go to [vercel.com/new](https://vercel.com/new)
2. Click **"Import Git Repository"**
3. Select your `legacyclaim` repo
4. Framework Preset: **Other**
5. Root Directory: **`.`** (the project root — leave as-is)
6. Build Command: **leave blank** (or `npm install`)
7. Output Directory: **`.`**
8. Click **"Deploy"**

Vercel will detect `vercel.json` and wire everything automatically.

---

## Step 3 — Add environment variables

In Vercel: **Project → Settings → Environment Variables**

Add each variable below. Set Environment to **Production, Preview, Development** for all of them.

### Required — app crashes without these

| Variable | Value |
|----------|-------|
| `SUPABASE_URL` | `https://YOUR_PROJECT_ID.supabase.co` |
| `SUPABASE_SERVICE_ROLE_KEY` | `eyJ...` (service role key from Supabase → Settings → API) |
| `SUPABASE_ANON_KEY` | `eyJ...` (anon key from Supabase) |
| `JWT_SECRET` | Any 40+ character random string |
| `JWT_REFRESH_SECRET` | A different 40+ character random string |
| `NODE_ENV` | `production` |

### Optional — defaults work fine

| Variable | Value |
|----------|-------|
| `SUPABASE_BUCKET_DOCUMENTS` | `legacyclaim-documents` |
| `SUPABASE_BUCKET_PROFILE` | `legacyclaim-profiles` |
| `JWT_EXPIRES_IN` | `7d` |
| `JWT_REFRESH_EXPIRES_IN` | `30d` |
| `MAX_FILE_SIZE_MB` | `10` |
| `API_VERSION` | `v1` |

> **CORS_ORIGINS is not needed on Vercel.** Your frontend and API functions
> share the same domain (e.g. `legacyclaim.vercel.app`), so there is no
> cross-origin request. CORS is only needed if you later use a custom domain
> for the frontend that differs from the API domain.

After adding variables, click **"Save"** — Vercel will trigger a redeploy automatically.

---

## Step 4 — Verify the deployment

Open these URLs (replace with your actual Vercel URL):

### Health check
```
https://legacyclaim.vercel.app/api/health
```
Expected:
```json
{ "status": "ok", "service": "LegacyClaim API", "environment": "production" }
```

### Discovery endpoint (public)
```bash
curl -X POST https://legacyclaim.vercel.app/api/v1/discovery \
  -F "name=Test User" \
  -F "mobile=9876543210"
```
Expected: `{"success":true,"data":{"report_number":"LCR-2026-XXXX"}}`

### Partner signup (public)
```bash
curl -X POST https://legacyclaim.vercel.app/api/v1/partners \
  -H "Content-Type: application/json" \
  -d '{"name":"Test CA","email":"test@ca.com","phone":"9800000000","partner_type":"ca"}'
```

### Value estimate (public, no auth)
```
https://legacyclaim.vercel.app/api/v1/features/estimate?claim_type=iepf&share_quantity=200
```

---

## Step 5 — config.js (already correct)

`config.js` auto-detects the environment:

```js
// On Vercel (any domain that isn't localhost):
API_BASE_URL = '/api/v1'          // relative — same origin, no CORS

// On localhost with plain http-server:
API_BASE_URL = 'http://localhost:3000/api/v1'
```

**No changes needed.** The detection is automatic based on `window.location.hostname`.

---

## Step 6 — Local development with Vercel CLI

To run the full stack locally (frontend + functions together on one port):

```bash
npm install -g vercel

cd legacyclaim-vercel

# Create local env file
cp .env.example .env
# Edit .env — add your Supabase keys

vercel dev
# → http://localhost:3000
```

`vercel dev` serves the frontend AND runs all API functions on the same port,
so relative paths (`/api/v1/...`) work identically to production.

---

## Step 7 — Files to delete from the old project

Now that everything runs on Vercel, you can delete:

```
# Old Render/standalone backend (no longer needed):
backend/                         ← entire folder
backend/src/index.js             ← Express standalone server
backend/render.yaml
backend/.env.example
backend/README.md

# Old config files:
RENDER_DEPLOY.md                 ← Render instructions
LOCAL_SETUP.md                   ← old local setup guide
```

**Keep these** (they moved into the Vercel project):
```
lib/                             ← controllers, services, middleware, utils
api/                             ← Vercel Functions
vercel.json
config.js
```

---

## How routing works

Vercel receives every request. `vercel.json` rewrites tell it which
Function file to run:

```
Browser → GET /api/v1/discovery/LCR-2026-0042
       → vercel.json rewrites to → api/v1/discovery.js
       → Express router inside matches GET /:id
       → discoveryController.getReport()
       → Supabase query
       → JSON response
```

Frontend calls like `fetch('/api/v1/discovery', {...})` work because
the frontend and functions are on the same domain — no hostname,
no CORS, no extra configuration.

---

## Vercel free plan limits

| Limit | Free tier | This project |
|-------|-----------|-------------|
| Serverless Function executions | 100,000 / month | Well within |
| Function memory | 1024 MB max | Set to 512 MB in vercel.json |
| Function timeout | 10s (Hobby) / 30s (Pro) | Set to 30s — upgrade if needed |
| Bandwidth | 100 GB / month | Well within |
| Deployments | Unlimited | ✓ |

> **Note on timeout:** The free (Hobby) plan caps functions at 10 seconds.
> The wealth discovery scan includes a simulated 2-second delay — it will
> work. File uploads to Supabase are also well within 10s.
> If you enable real external API calls (IEPF, NSDL), upgrade to Pro ($20/mo)
> for the 30-second timeout.

---

## Common errors

| Error | Cause | Fix |
|-------|-------|-----|
| `500` on any route | Missing `SUPABASE_URL` or `SUPABASE_SERVICE_ROLE_KEY` | Add them in Vercel → Environment Variables |
| `404` on `/api/v1/...` | `vercel.json` rewrite not matching | Check the exact path in vercel.json |
| `401` on authenticated routes | JWT_SECRET not set | Add `JWT_SECRET` in Vercel env vars |
| Function timeout | Slow Supabase query | Check Supabase → Logs for slow queries |
| File upload fails | Supabase bucket doesn't exist | Create `legacyclaim-documents` bucket in Supabase Storage |
| `CORS` error in browser console | Custom domain mismatch | Add `CORS_ORIGINS=https://yourdomain.com` to Vercel env vars |

---

*LegacyClaim — Claim Your Financial Legacy*
