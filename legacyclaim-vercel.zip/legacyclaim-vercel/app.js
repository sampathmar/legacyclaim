/* ============================================================
   LegacyClaim — app.js  (PRODUCTION)
   No offline fallbacks. All API calls are mandatory.
   Errors surface to the user. No fake success states.
   ============================================================ */

// ── Environment Config ─────────────────────────────────────────────────────
// Set by config.js (loaded before this script).
// Production:  https://legacyclaim-api.onrender.com/api/v1
// Development: http://localhost:3000/api/v1
const ENV = {
  API_BASE_URL:
    window.LC_CONFIG?.API_BASE_URL   // set by config.js
    || window.LC_API                  // shorthand set by config.js
    || 'http://localhost:3000/api/v1' // hard fallback for local dev
};

// ── App State ──────────────────────────────────────────────────────────────
const LC = {
  currentPage:         'home',
  theme:               localStorage.getItem('lc-theme') || 'dark',
  waStep:              0,
  waClaim:             null,
  fastTrack:           false,
  isNRI:               false,
  certData:            null,
  partnerType:         null,
  countdown:           null,
  token:               localStorage.getItem('lc-token') || null,
  user:                JSON.parse(localStorage.getItem('lc-user') || 'null'),
  activeReportId:      null,
  activeReportNumber:  null,
  activeCaseId:        null,
  reportPollTimer:     null,
};

// ══════════════════════════════════════════════════════════════════════════
// PRODUCTION API LAYER
// ══════════════════════════════════════════════════════════════════════════

// Central fetch — throws meaningful errors, never swallows them
async function api(path, options = {}) {
  const url     = `${ENV.API_BASE_URL}${path}`;
  const headers = { ...(options.headers || {}) };

  if (LC.token) headers['Authorization'] = `Bearer ${LC.token}`;
  if (options.body && !(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }

  const controller = new AbortController();
  const timeout    = setTimeout(() => controller.abort(), 20000);

  try {
    const res = await fetch(url, { ...options, headers, signal: controller.signal });
    clearTimeout(timeout);

    // Parse body regardless of status
    let data;
    try { data = await res.json(); } catch { data = {}; }

    if (!res.ok) {
      // Surface the exact backend message when available
      const msg = data?.message || data?.error || data?.errors?.[0]?.msg || `Server error (${res.status})`;
      const err  = new Error(msg);
      err.status  = res.status;
      err.data    = data;
      err.isApi   = true;
      throw err;
    }
    return data;

  } catch (err) {
    clearTimeout(timeout);

    if (err.isApi) throw err; // already formatted above

    // Network / abort errors — give users a clear message
    if (err.name === 'AbortError') {
      const e = new Error('Request timed out. Please check your connection and try again.');
      e.isNetwork = true; throw e;
    }
    if (err.name === 'TypeError' || err.message?.includes('Failed to fetch') || err.message?.includes('NetworkError')) {
      const e = new Error('Cannot reach the server. Please check your internet connection.');
      e.isNetwork = true; throw e;
    }
    throw err;
  }
}

const apiGet   = path         => api(path, { method: 'GET' });
const apiPost  = (path, body) => api(path, { method: 'POST',  body: body instanceof FormData ? body : JSON.stringify(body) });
const apiPatch = (path, body) => api(path, { method: 'PATCH', body: JSON.stringify(body) });

// ── Auth ───────────────────────────────────────────────────────────────────
function saveAuth(token, user) {
  LC.token = token; LC.user = user;
  localStorage.setItem('lc-token', token);
  localStorage.setItem('lc-user',  JSON.stringify(user));
}
function clearAuth() {
  LC.token = null; LC.user = null;
  localStorage.removeItem('lc-token');
  localStorage.removeItem('lc-user');
}
function isLoggedIn() { return !!LC.token && !!LC.user; }

// ══════════════════════════════════════════════════════════════════════════
// PRODUCTION ERROR & LOADING UI
// ══════════════════════════════════════════════════════════════════════════

// Categorise error for display
function classifyError(err) {
  if (err.isNetwork)  return { type: 'network',     icon: '📡', msg: err.message };
  if (err.status === 400) return { type: 'validation', icon: '⚠',  msg: err.message };
  if (err.status === 401) return { type: 'auth',       icon: '🔒', msg: 'Session expired. Please log in again.' };
  if (err.status === 409) return { type: 'conflict',   icon: '⚠',  msg: err.message };
  if (err.status === 422) return { type: 'validation', icon: '⚠',  msg: err.message };
  if (err.status >= 500)  return { type: 'server',     icon: '🚨', msg: 'Server error. Our team has been notified. Please try again shortly.' };
  return { type: 'unknown', icon: '⚠', msg: err.message || 'Something went wrong.' };
}

// Inline error block — rendered inside a form container
function showInlineError(containerId, err) {
  const el = document.getElementById(containerId);
  const { icon, msg, type } = classifyError(err);

  const html = `
    <div class="api-error" data-type="${type}" role="alert" style="
      display:flex;align-items:flex-start;gap:10px;
      padding:14px 16px;margin-top:14px;border-radius:var(--r-md);
      background:var(--rose-dim);border:1px solid rgba(192,58,75,0.35);
      font-size:0.85rem;color:var(--text-2);line-height:1.5;
    ">
      <span style="font-size:1.1rem;flex-shrink:0;margin-top:1px;">${icon}</span>
      <div>
        <div style="font-weight:600;color:var(--rose);margin-bottom:2px;">${typeLabel(type)}</div>
        <div>${msg}</div>
        ${type === 'network' ? '<div style="font-size:0.78rem;color:var(--text-4);margin-top:6px;">Make sure the backend server is running at <code style="background:var(--bg-4);padding:2px 6px;border-radius:4px;">' + ENV.API_BASE_URL + '</code></div>' : ''}
      </div>
    </div>`;

  if (el) {
    el.innerHTML     = html;
    el.style.display = 'block';
    el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } else {
    // Fallback: toast if container not in DOM
    showToast(`${icon} ${msg}`, 'error');
  }
}

function typeLabel(type) {
  return { network:'Connection Error', validation:'Validation Error', auth:'Authentication Error', conflict:'Conflict', server:'Server Error', unknown:'Error' }[type] || 'Error';
}

function clearInlineError(containerId) {
  const el = document.getElementById(containerId);
  if (el) { el.innerHTML = ''; el.style.display = 'none'; }
}

// Success banner — green, auto-scrolls into view
function showInlineSuccess(containerId, { icon = '✅', title, message, meta = '' } = {}) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = `
    <div style="
      display:flex;align-items:flex-start;gap:12px;
      padding:18px 20px;border-radius:var(--r-md);
      background:var(--emerald-dim);border:1px solid rgba(30,158,126,0.35);
    ">
      <span style="font-size:1.5rem;flex-shrink:0;">${icon}</span>
      <div>
        <div style="font-weight:600;color:#3ECAA0;margin-bottom:4px;">${title}</div>
        <div style="font-size:0.875rem;color:var(--text-2);">${message}</div>
        ${meta ? `<div style="font-family:var(--ff-mono);font-size:0.78rem;color:var(--gold-light);margin-top:8px;">${meta}</div>` : ''}
      </div>
    </div>`;
  el.style.display = 'block';
  el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Button states
function btnLoading(btn, label = '⟳ Processing...') {
  btn._orig    = btn.innerHTML;
  btn.innerHTML = `<span style="display:inline-flex;align-items:center;gap:6px;">${label}</span>`;
  btn.disabled  = true;
  btn.setAttribute('aria-busy', 'true');
}
function btnReset(btn) {
  if (btn._orig) btn.innerHTML = btn._orig;
  btn.disabled = false;
  btn.removeAttribute('aria-busy');
}

function fmtINR(n) {
  if (!n || isNaN(n)) return '₹—';
  return '₹' + Number(n).toLocaleString('en-IN');
}

// ── Spinner overlay for file operations ───────────────────────────────────
function showSpinner(spinnerId, msg = '') {
  const el = document.getElementById(spinnerId);
  if (!el) return;
  el.innerHTML = `
    <div style="display:flex;flex-direction:column;align-items:center;gap:12px;padding:32px;">
      <div class="scan-loader" style="width:240px;"><div class="scan-loader__bar"></div></div>
      <p style="color:var(--text-3);font-size:0.875rem;">${msg}</p>
    </div>`;
  el.style.display = 'block';
}
function hideSpinner(spinnerId) {
  const el = document.getElementById(spinnerId);
  if (el) { el.innerHTML = ''; el.style.display = 'none'; }
}

// ── Page Router ────────────────────────────────────────────────────────────
function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const page = document.getElementById('page-' + id);
  if (page) { page.classList.add('active'); window.scrollTo({ top: 0, behavior: 'instant' }); LC.currentPage = id; }
  document.querySelectorAll('.navbar__nav a').forEach(a => a.classList.remove('active'));
  document.getElementById('nav-' + id)?.classList.add('active');
  document.getElementById('mobileMenu')?.classList.remove('open');
  triggerFadeIns();
  if (id === 'dashboard') loadDashboardStats();
  if (id === 'admin')     loadAdminStats();
}

// ── Theme ──────────────────────────────────────────────────────────────────
function setTheme(t) {
  LC.theme = t;
  document.documentElement.setAttribute('data-theme', t);
  localStorage.setItem('lc-theme', t);
  const btn = document.getElementById('themeToggle');
  if (btn) btn.textContent = t === 'dark' ? '☀️' : '🌙';
}
function toggleTheme() { setTheme(LC.theme === 'dark' ? 'light' : 'dark'); }

// ── Mobile Menu ────────────────────────────────────────────────────────────
function toggleMobile() { document.getElementById('mobileMenu')?.classList.toggle('open'); }

// ── Scroll ─────────────────────────────────────────────────────────────────
window.addEventListener('scroll', () => {
  document.getElementById('navbar')?.classList.toggle('scrolled', window.scrollY > 40);
  document.getElementById('stickyCta')?.classList.toggle('show', window.scrollY > 600);
  triggerFadeIns();
});
function triggerFadeIns() {
  document.querySelectorAll('.fade-in:not(.visible)').forEach(el => {
    if (el.getBoundingClientRect().top < window.innerHeight - 60) el.classList.add('visible');
  });
}
window.addEventListener('load', () => {
  setTimeout(triggerFadeIns, 100);
  setTheme(LC.theme);
  startCountdown();
  animateChartBars();
  if (isLoggedIn()) loadDashboardStats();
});

// ── Modal ──────────────────────────────────────────────────────────────────
function openModal(id)  { const el=document.getElementById(id); if(el){el.classList.add('open');document.body.style.overflow='hidden';} }
function closeModal(id) { const el=document.getElementById(id); if(el){el.classList.remove('open');document.body.style.overflow='';} }
function closeModalOnOverlay(e, id) { if (e.target.id === id) closeModal(id); }
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open')); document.body.style.overflow=''; }
});

// ── FAQ & Legal ────────────────────────────────────────────────────────────
function toggleFaq(btn) {
  const item   = btn.closest('.faq-item');
  const answer = item.querySelector('.faq-answer');
  const isOpen = item.classList.contains('open');
  document.querySelectorAll('.faq-item.open').forEach(i => { i.classList.remove('open'); i.querySelector('.faq-answer').style.maxHeight='0'; });
  if (!isOpen) { item.classList.add('open'); answer.style.maxHeight = answer.scrollHeight + 'px'; }
}
function showLegalTab(id, btn) {
  document.querySelectorAll('.legal-tab').forEach(t => t.style.display='none');
  const el = document.getElementById('legal-'+id); if(el) el.style.display='block';
  document.querySelectorAll('.legal-tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}

// ── Fee Calculator ─────────────────────────────────────────────────────────
function calcFee(val) {
  const v  = parseFloat(val);
  const res  = document.getElementById('feeCalcResult');
  const note = document.getElementById('feeCalcNote');
  if (!res) return;
  if (!v || v <= 0) { res.textContent='₹ —'; if(note) note.textContent='Enter a recovery value to see estimate'; return; }
  res.textContent = fmtINR(Math.round(v*(LC.fastTrack?0.10:0.08)))+' – '+fmtINR(Math.round(v*(LC.fastTrack?0.20:0.18)));
  if (note) note.textContent = LC.fastTrack ? 'Includes +2% fast track fee' : '8–18% success fee range';
}

// ══════════════════════════════════════════════════════════════════════════
// 1. DISCOVERY ENGINE  →  POST /api/v1/discovery
// ══════════════════════════════════════════════════════════════════════════
async function submitDiscoveryForm(e) {
  e.preventDefault();
  const form = e.target;
  const btn  = form.querySelector('button[type=submit]');

  clearInlineError('discoveryFormError');
  btnLoading(btn, '⟳ Scanning your records...');

  // Collect from either the hero quick-scan or the full discovery-page form
  const get = sel => form.querySelector(sel)?.value?.trim() || '';
  const name       = get('[placeholder*="Name"]') || get('[placeholder*="name"]');
  const mobile     = get('[type=tel]');
  const pan        = (get('[placeholder*="PAN"]') || get('[placeholder*="pan"]')).toUpperCase();
  const dob        = get('[type=date]');
  const fatherName = get('[placeholder*="Father"]') || get('[placeholder*="father"]');
  const email      = get('[type=email]');
  const city       = get('[placeholder*="City"]')   || get('[placeholder*="city"]');
  const fileInput  = form.querySelector('[type=file]');

  // Client-side required field check
  if (!name) { btnReset(btn); showInlineError('discoveryFormError', { isApi:true, status:400, message:'Please enter your full name.' }); return; }
  if (!mobile) { btnReset(btn); showInlineError('discoveryFormError', { isApi:true, status:400, message:'Please enter your mobile number.' }); return; }

  try {
    const fd = new FormData();
    fd.append('name',   name);
    fd.append('mobile', mobile);
    if (pan)        fd.append('pan',         pan);
    if (dob)        fd.append('dob',         dob);
    if (fatherName) fd.append('father_name', fatherName);
    if (email)      fd.append('email',       email);
    if (city)       fd.append('city',        city);
    if (fileInput?.files?.[0]) fd.append('pan_doc', fileInput.files[0]);

    const data = await api('/discovery', { method: 'POST', body: fd });

    LC.activeReportId     = data.data?.report_id     || null;
    LC.activeReportNumber = data.data?.report_number || null;

    btnReset(btn);

    // Show report-initiated success, then navigate
    showInlineSuccess('discoveryFormSuccess', {
      icon:    '🔍',
      title:   'Discovery Started',
      message: 'Your Wealth Discovery Report is being generated. Scanning 5 databases now.',
      meta:    LC.activeReportNumber ? `Report: ${LC.activeReportNumber}` : '',
    });

    // Small delay so user sees the success state, then navigate to report page
    setTimeout(() => {
      showPage('report');
      startReportScan(); // start UI animation
      if (LC.activeReportId) pollReportResults(LC.activeReportId); // overlay real data
    }, 1400);

  } catch (err) {
    btnReset(btn);
    showInlineError('discoveryFormError', err);
    if (err.status === 401) clearAuth();
  }
}

// Poll until ready — inject real backend data into scan rows
async function pollReportResults(reportId) {
  let attempts = 0;
  async function poll() {
    try {
      const data   = await apiGet(`/discovery/${reportId}`);
      const report = data.data?.report || data.data;
      if (report?.status === 'ready')  { hydrateReportUI(report); return; }
      if (report?.status === 'failed') {
        showToast('Scan could not complete — contact support if this persists.', 'error');
        return;
      }
      if (++attempts < 15) setTimeout(poll, 2000);
      else showToast('Scan is taking longer than expected. Check back shortly.', 'error');
    } catch (err) {
      // Poll errors are shown once, don't loop on persistent failures
      if (attempts === 0) showToast('Could not fetch scan results: ' + err.message, 'error');
    }
  }
  setTimeout(poll, 3000);
}

// Replace scan row placeholders with real data from backend
function hydrateReportUI(report) {
  const map = [
    { detected: report.shares_detected,    details: report.shares_details    },
    { detected: report.iepf_detected,      details: report.iepf_details      },
    { detected: report.pf_detected,        details: report.pf_details        },
    { detected: report.insurance_detected, details: report.insurance_details },
    { detected: report.bank_detected,      details: report.bank_details      },
  ];

  document.querySelectorAll('.report-scan-row').forEach((row, i) => {
    const entry = map[i]; if (!entry) return;
    const dot = row.querySelector('.scan-dot');
    const val = row.querySelector('.scan-value');
    row.classList.toggle('detected', !!entry.detected);
    if (dot) dot.className = 'scan-dot ' + (entry.detected ? 'green' : 'grey');
    if (val) {
      const raw = entry.details?.estimated_value || entry.details?.estimated_balance;
      if (entry.detected && raw) {
        val.textContent = fmtINR(Math.round(raw * 0.75)) + ' – ' + fmtINR(Math.round(raw * 1.25));
        val.style.color = '';
      } else if (!entry.detected) {
        val.textContent = 'Not detected';
        val.style.color = 'var(--text-4)';
      }
    }
  });

  if (report.total_estimated) {
    const totalEl = document.getElementById('reportTotal');
    const rangeEl = totalEl?.querySelector('.estimate-range');
    if (rangeEl) rangeEl.textContent = fmtINR(Math.round(report.total_estimated * 0.80)) + ' – ' + fmtINR(Math.round(report.total_estimated * 1.30));
    if (totalEl) { totalEl.style.display='block'; totalEl.style.animation='fadeUp 0.5s var(--ease) both'; }
  }
}

// Animated scanning progress (visual only — real data overlays this when ready)
function startReportScan() {
  const rows = document.querySelectorAll('.report-scan-row');
  rows.forEach((row, i) => {
    const dot = row.querySelector('.scan-dot');
    const val = row.querySelector('.scan-value');
    if (dot) dot.className = 'scan-dot amber';
    if (val) val.textContent = 'Scanning...';
    // Amber animation — real data will replace when poll returns
    setTimeout(() => {
      if (dot?.className.includes('amber')) dot.className = 'scan-dot amber'; // keep pulsing
    }, (i + 1) * 900);
  });
  // Keep loader bar visible until backend data arrives
  const loader = document.querySelector('.scan-loader');
  if (loader) loader.style.display = 'block';
}

// ══════════════════════════════════════════════════════════════════════════
// 2. DOCUMENT UPLOAD  →  POST /api/v1/features/certificate/upload
// ══════════════════════════════════════════════════════════════════════════
function initCertUpload() {
  const zone  = document.getElementById('certDropZone');
  const input = document.getElementById('certFileInput');
  if (!zone || !input) return;
  zone.addEventListener('dragover',  e => { e.preventDefault(); zone.classList.add('drag-active'); });
  zone.addEventListener('dragleave', ()  => zone.classList.remove('drag-active'));
  zone.addEventListener('drop', e => {
    e.preventDefault(); zone.classList.remove('drag-active');
    if (e.dataTransfer?.files[0]) processCertFile(e.dataTransfer.files[0]);
  });
  input.addEventListener('change', () => { if (input.files[0]) processCertFile(input.files[0]); });
}

async function processCertFile(file) {
  const preview  = document.getElementById('certPreview');
  const result   = document.getElementById('certAiResult');
  const errBlock = document.getElementById('certUploadError');

  if (preview) preview.textContent = '📄 ' + file.name;
  if (result)  result.style.display = 'none';
  clearInlineError('certUploadError');
  showSpinner('certSpinner', '🤖 AI reading your certificate — extracting company, folio, and shares...');

  // Client-side file validation
  const allowedTypes = ['application/pdf','image/jpeg','image/png','image/webp'];
  if (!allowedTypes.includes(file.type)) {
    hideSpinner('certSpinner');
    showInlineError('certUploadError', { isApi:true, status:400, message:'Only PDF, JPG, PNG or WebP files are accepted.' });
    return;
  }
  if (file.size > 10 * 1024 * 1024) {
    hideSpinner('certSpinner');
    showInlineError('certUploadError', { isApi:true, status:400, message:'File must be under 10 MB.' });
    return;
  }

  try {
    const fd = new FormData();
    fd.append('certificate', file);
    fd.append('create_case', 'false');

    const data      = await api('/features/certificate/upload', { method: 'POST', body: fd });
    const extracted = data.data?.extracted || data.data;
    if (!extracted?.company_name && !extracted?.folio_number) {
      throw Object.assign(new Error('AI could not extract data from this file. Please upload a clearer image.'), { isApi:true, status:422 });
    }

    LC.certData = {
      company:    extracted.company_name   || '—',
      folio:      extracted.folio_number   || '—',
      shares:     extracted.share_quantity || 0,
      year:       extracted.share_year     || '—',
      confidence: Math.round((extracted.confidence || 0.80) * 100),
    };

    hideSpinner('certSpinner');
    renderCertResult();
    showToast('Certificate extracted successfully', 'success');

  } catch (err) {
    hideSpinner('certSpinner');
    showInlineError('certUploadError', err);
    if (err.status === 401) clearAuth();
  }
}

function renderCertResult() {
  const result = document.getElementById('certAiResult');
  const set    = (id, val) => { const el = document.getElementById(id); if(el) el.textContent = val; };
  set('certCompany',  LC.certData.company);
  set('certFolio',    LC.certData.folio);
  set('certShares',   LC.certData.shares + ' shares');
  set('certYear',     LC.certData.year);
  set('certConf',     LC.certData.confidence + '% confidence');
  const min = (LC.certData.shares||200) * 120;
  const max = (LC.certData.shares||200) * 480;
  set('certEstimate', fmtINR(min) + ' – ' + fmtINR(max));
  if (result) result.style.display = 'block';
}

// ── Family Discovery ───────────────────────────────────────────────────────
function updateFamilyTree() {
  const investor = document.getElementById('fdInvestor')?.value || '';
  const father   = document.getElementById('fdFather')?.value   || '';
  const grandpa  = document.getElementById('fdGrandpa')?.value  || '';
  const n = (id, val, label) => { const el=document.getElementById(id); if(el){el.textContent=val||label; el.classList.toggle('filled',!!val);} };
  n('familyNodeInvestor', investor, 'Investor Name');
  n('familyNodeFather',   father,   'Father Name');
  n('familyNodeGrandpa',  grandpa,  'Grandfather');
}

async function submitFamilyForm(e) {
  e.preventDefault();
  const form = e.target;
  const btn  = form.querySelector('button[type=submit]');
  clearInlineError('familyFormError');
  btnLoading(btn, '⟳ Starting family search...');

  const investor_name    = document.getElementById('fdInvestor')?.value?.trim() || '';
  const father_name      = document.getElementById('fdFather')?.value?.trim()   || '';
  const grandfather_name = document.getElementById('fdGrandpa')?.value?.trim()  || '';
  const old_address      = form.querySelector('[placeholder*="ddress"]')?.value?.trim() || '';
  const state            = form.querySelector('select')?.value || '';
  const mobile           = form.querySelector('[type=tel]')?.value?.trim() || '';

  if (!investor_name) {
    btnReset(btn);
    showInlineError('familyFormError', { isApi:true, status:400, message:'Please enter the investor\'s full name.' });
    return;
  }

  try {
    let data;
    if (isLoggedIn()) {
      data = await apiPost('/features/family-discovery', { investor_name, father_name, grandfather_name, old_address, state });
    } else {
      // Public path: submit as discovery report
      const fd = new FormData();
      fd.append('name',        investor_name);
      fd.append('mobile',      mobile || '0000000000');
      fd.append('father_name', father_name);
      data = await api('/discovery', { method:'POST', body:fd });
    }

    const reportNum = data.data?.case_id || data.data?.report_number || '';
    btnReset(btn);

    showInlineSuccess('familyFormSuccess', {
      icon:    '👨‍👩‍👧',
      title:   'Family Search Started',
      message: 'Multi-generation wealth search has been initiated. Our team will contact you within 24 hours.',
      meta:    reportNum ? `Reference: ${reportNum}` : '',
    });
    setTimeout(() => { showPage('report'); startReportScan(); if (LC.activeReportId) pollReportResults(LC.activeReportId); }, 1400);

  } catch (err) {
    btnReset(btn);
    showInlineError('familyFormError', err);
  }
}

// ── Toggles ────────────────────────────────────────────────────────────────
function toggleFastTrack(el) {
  LC.fastTrack = !LC.fastTrack;
  el.classList.toggle('on', LC.fastTrack);
  const pill = document.getElementById('fastTrackPill');
  if (pill) pill.style.display = LC.fastTrack ? 'inline-flex' : 'none';
  const feeNote = document.getElementById('fastTrackFeeNote');
  if (feeNote) feeNote.style.display = LC.fastTrack ? 'block' : 'none';
  const feeInput = document.getElementById('feeInput');
  if (feeInput?.value) calcFee(feeInput.value);
}

function toggleNRI(el) {
  LC.isNRI = !LC.isNRI;
  el.classList.toggle('on', LC.isNRI);
  const fields = document.getElementById('nriFields');
  if (fields) { fields.style.display = LC.isNRI ? 'block' : 'none'; if(LC.isNRI) fields.style.animation='fadeUp 0.4s var(--ease) both'; }
}

// ══════════════════════════════════════════════════════════════════════════
// 3. PARTNER SIGNUP  →  POST /api/v1/partners
// ══════════════════════════════════════════════════════════════════════════
function selectPartnerType(type, el) {
  LC.partnerType = type;
  document.querySelectorAll('.partner-type-card').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
  const inp = document.getElementById('partnerTypeInput');
  if (inp) inp.value = type;
}

async function submitPartnerForm(e) {
  e.preventDefault();
  const form = e.target;
  const btn  = form.querySelector('button[type=submit]');
  clearInlineError('partnerFormError');
  btnLoading(btn, '⟳ Submitting application...');

  const inputs      = [...form.querySelectorAll('input, select')];
  const byHint      = hint => inputs.find(i => i.placeholder?.toLowerCase().includes(hint.toLowerCase()) || i.name === hint)?.value?.trim() || '';
  const name        = byHint('name') || byHint('your name');
  const firm_name   = byHint('firm') || byHint('organisation');
  const email       = form.querySelector('[type=email]')?.value?.trim() || '';
  const phone       = form.querySelector('[type=tel]')?.value?.trim()   || '';
  const city        = byHint('city');
  const state       = form.querySelector('select')?.value || '';
  const partner_type = LC.partnerType || document.getElementById('partnerTypeInput')?.value || '';

  // Client-side validation
  const missing = [];
  if (!name)         missing.push('name');
  if (!email)        missing.push('email');
  if (!phone)        missing.push('phone');
  if (!partner_type) missing.push('partner type (select CA / Lawyer / Broker / Bank Agent above)');
  if (missing.length) {
    btnReset(btn);
    showInlineError('partnerFormError', { isApi:true, status:400, message:`Please fill in: ${missing.join(', ')}.` });
    return;
  }

  try {
    const data        = await apiPost('/partners', { name, firm_name, email, phone, city, state, partner_type });
    const partnerCode = data.data?.partner_code || '';
    btnReset(btn);

    const success = document.getElementById('partnerSuccess');
    if (success) {
      success.innerHTML = `
        <div style="font-size:2rem;margin-bottom:10px;">🎉</div>
        <div style="font-weight:600;color:#3ECAA0;margin-bottom:8px;">Application Submitted!</div>
        ${partnerCode ? `<p style="font-size:0.875rem;color:var(--text-3);margin-bottom:8px;">Your partner code: <strong style="color:var(--gold-light);font-family:var(--ff-mono);">${partnerCode}</strong></p>` : ''}
        <p style="font-size:0.82rem;color:var(--text-3);">Our team will activate your account within 48 hours. Dashboard access sent to <strong>${email}</strong>.</p>`;
      success.style.display = 'block';
      form.style.display    = 'none';
    }
    showToast('Application submitted! We\'ll be in touch within 48 hours.', 'success');

  } catch (err) {
    btnReset(btn);
    showInlineError('partnerFormError', err);
    if (err.status === 401) clearAuth();
  }
}

// ══════════════════════════════════════════════════════════════════════════
// 4. DASHBOARD STATS  →  GET /api/v1/dashboard  +  /dashboard/admin
// ══════════════════════════════════════════════════════════════════════════
async function loadDashboardStats() {
  if (!isLoggedIn()) return;

  const errBlock = document.getElementById('dashboardLoadError');
  clearInlineError('dashboardLoadError');

  try {
    const data  = await apiGet('/dashboard');
    const stats = data.data || {};
    const set   = (id, val) => { const el=document.getElementById(id); if(el) el.textContent=val; };
    set('dashTotalCases',  stats.total_cases     ?? '—');
    set('dashEstimated',   stats.total_estimated  ? fmtINR(stats.total_estimated) : '—');
    set('dashActiveCases', stats.active_cases     ?? '—');
    set('dashDocsPending', stats.docs_pending     ?? '—');
    if (Array.isArray(stats.recent_cases) && stats.recent_cases.length) renderRecentCasesTable(stats.recent_cases);
    if (stats.feasibility_due_at) LC.feasibilityDue = new Date(stats.feasibility_due_at);
  } catch (err) {
    // Show error in dashboard — don't silently swallow
    showInlineError('dashboardLoadError', err);
  }
}

async function loadAdminStats() {
  if (!isLoggedIn()) return;
  clearInlineError('adminLoadError');
  try {
    const data  = await apiGet('/dashboard/admin');
    const stats = data.data || {};
    const set   = (id, val) => { const el=document.getElementById(id); if(el) el.textContent=val; };
    set('adminTotalCases',     stats.total_cases       ?? '—');
    set('adminDiscoveryCount', stats.discovery_count   ?? '—');
    set('adminTotalRecovery',  stats.total_recovered    ? fmtINR(stats.total_recovered)  : '—');
    set('adminRevenue',        stats.total_revenue      ? fmtINR(stats.total_revenue)    : '—');
    set('adminPartners',       stats.active_partners   ?? '—');
    set('adminWaLeads',        stats.whatsapp_leads     ?? '—');
    set('adminFeasibility',    stats.feasibility_pending ?? '—');
    set('adminRecovered',      stats.recovered_cases   ?? '—');
  } catch (err) {
    showInlineError('adminLoadError', err);
  }
}

function renderRecentCasesTable(cases) {
  const tbody = document.getElementById('recentCasesTable');
  if (!tbody) return;
  const bc = s => ({ recovered:'emerald', filed:'blue', approved:'emerald', under_process:'amber', docs_pending:'muted', new_lead:'gold', closed:'muted' })[s]||'muted';
  const fs = s => (s||'').replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
  const sc = s => s==='high_value'?'high':s==='medium_value'?'medium':'low';
  tbody.innerHTML = cases.slice(0,5).map(c=>`
    <div class="mini-table-row">
      <span class="case-id">${c.case_id}</span>
      <span class="case-name">${c.title||fs(c.claim_type)}</span>
      <span class="badge badge-${bc(c.status)}">${fs(c.status)}</span>
      <span class="lead-chip ${sc(c.lead_score)}" style="margin-left:8px;">${c.lead_score?c.lead_score.replace('_value',''):'—'}</span>
    </div>`).join('');
}

// ── Dashboard Nav ──────────────────────────────────────────────────────────
function dashNav(section) {
  document.querySelectorAll('.dash-nav-item').forEach(i => i.classList.remove('active'));
  document.querySelector(`[data-section="${section}"]`)?.classList.add('active');
  document.querySelectorAll('.dash-section').forEach(s => s.style.display='none');
  const target = document.getElementById('dash-'+section);
  if (target) target.style.display='block';
  if (section === 'timeline' && LC.activeCaseId) loadCaseProbability();
}

async function loadCaseProbability() {
  if (!isLoggedIn() || !LC.activeCaseId) return;
  try {
    const data = await apiGet(`/features/cases/${LC.activeCaseId}/probability`);
    if (data.data?.probability) updateProbability(data.data.probability);
  } catch (err) {
    showToast('Could not load probability: ' + err.message, 'error');
  }
}

// ── Probability & Estimate widgets ────────────────────────────────────────
function animateChartBars() {
  document.querySelectorAll('.chart-bar').forEach((bar, i) => {
    const h = 20 + Math.random() * 80;
    setTimeout(() => { bar.style.height = h+'%'; }, i*80);
  });
}

function updateProbability(level) {
  const card=document.getElementById('probCard');
  const score=document.getElementById('probScore');
  const label=document.getElementById('probLabel');
  const desc=document.getElementById('probDesc');
  if (!card) return;
  card.className='prob-card '+level;
  const d={high:{score:'85%',label:'High Probability',desc:'Strong document set and active company match. High chance of successful recovery.'},medium:{score:'55%',label:'Medium Probability',desc:'Some documents present. Recovery likely with additional verification.'},low:{score:'25%',label:'Low Probability',desc:'Limited documentation. Additional records needed to proceed.'}}[level];
  if(score) score.textContent=d.score; if(label) label.textContent=d.label; if(desc) desc.textContent=d.desc;
}

async function updateEstimate(shares) {
  const estEl = document.getElementById('liveEstimate');
  if (!estEl) return;
  try {
    const data = await apiGet(`/features/estimate?claim_type=physical_shares&share_quantity=${shares}`);
    const est  = data.data?.estimate;
    if (est) { estEl.textContent = fmtINR(est.min)+' – '+fmtINR(est.max); return; }
  } catch { /* local fallback only for estimate slider */ }
  estEl.textContent = fmtINR(shares*120)+' – '+fmtINR(shares*480);
}

// ══════════════════════════════════════════════════════════════════════════
// 5. GENERIC FORMS  →  POST /api/v1/discovery  (contact, NRI, modal)
// ══════════════════════════════════════════════════════════════════════════
async function handleFormSubmit(e, successId) {
  e.preventDefault();
  const form    = e.target;
  const btn     = form.querySelector('button[type=submit]');
  const errId   = successId + 'Error';
  clearInlineError(errId);
  btnLoading(btn, '⟳ Sending...');

  const formPage = form.closest('.page')?.id || '';
  const fd       = new FormData();

  if (formPage === 'page-contact') {
    const name  = form.querySelector('[type=text]')?.value?.trim();
    const phone = form.querySelector('[type=tel]')?.value?.trim();
    const email = form.querySelector('[type=email]')?.value?.trim() || '';
    if (!name || !phone) {
      btnReset(btn);
      showInlineError(errId, { isApi:true, status:400, message:'Name and phone are required.' });
      return;
    }
    fd.append('name', name); fd.append('mobile', phone); if(email) fd.append('email', email);
  } else {
    const name  = form.querySelector('[type=text]')?.value?.trim();
    const phone = form.querySelector('[type=tel]')?.value?.trim();
    if (!name || !phone) {
      btnReset(btn);
      showInlineError(errId, { isApi:true, status:400, message:'Name and phone are required.' });
      return;
    }
    fd.append('name', name); fd.append('mobile', phone);
  }

  try {
    const data = await api('/discovery', { method:'POST', body:fd });
    btnReset(btn);

    showInlineSuccess(successId, {
      icon:    '✅',
      title:   'Message Received',
      message: 'Our team will contact you within 24 hours.',
      meta:    data.data?.report_number ? `Ref: ${data.data.report_number}` : '',
    });
    showToast('Enquiry submitted. We\'ll be in touch within 24 hours.', 'success');

  } catch (err) {
    btnReset(btn);
    showInlineError(errId, err);
    if (err.status === 401) clearAuth();
  }
}

// ── WhatsApp Bot ───────────────────────────────────────────────────────────
const WA_FLOWS = {
  0:{ bot:"👋 Hello! I'm LegacyClaim Assistant. I'll help you discover and recover forgotten wealth.\n\nWhat type of claim are you looking at?", options:['📈 Old Shares','🏦 IEPF Claim','👨‍👩‍👧 Legal Heir','💼 PF / EPF','🌍 NRI Claim','❓ Not sure'] },
  1:{ bot:"Great! Do you have the original share certificate or just the company name?", options:['✅ I have the certificate','📝 Just the company name','🤔 Not sure'] },
  2:{ bot:"Perfect. I'll need a few documents. Can you upload a photo or scan of the share certificate?", options:['📎 Upload now','⏰ I\'ll upload later','📞 Call me instead'] },
  3:{ bot:"Excellent! Our team will review your documents within 24 hours and send you a FREE Feasibility Report. Shall I register your inquiry now?", options:['✅ Yes, proceed','🔒 Is my data secure?'] },
  4:{ bot:"Your inquiry has been registered! 🎉\n\nRef: will be emailed to you. No upfront fee. Our team will contact you within 24 hours.", options:['🏠 Back to Home','📋 View Services'] },
};

let waLeadSaved = false;

function initWhatsAppBot() {
  LC.waStep=0; waLeadSaved=false;
  const body=document.getElementById('waBody'); if(body) body.innerHTML='';
  renderWaMessage();
}

function renderWaMessage() {
  const body=document.getElementById('waBody'); const optsCon=document.getElementById('waOptions');
  if (!body||!optsCon) return;
  const flow=WA_FLOWS[LC.waStep]; if(!flow) return;
  const bubble=document.createElement('div');
  bubble.className='wa-bubble bot'; bubble.style.animationDelay='0.1s';
  bubble.innerHTML=flow.bot.replace(/\n/g,'<br>')+`<div class="wa-time">${getTime()}</div>`;
  body.appendChild(bubble); body.scrollTop=body.scrollHeight;
  optsCon.innerHTML='';
  (flow.options||[]).forEach(opt=>{ const btn=document.createElement('button'); btn.className='wa-option'; btn.textContent=opt; btn.onclick=()=>waSelectOption(opt); optsCon.appendChild(btn); });
}

async function waSelectOption(text) {
  const body=document.getElementById('waBody'); if(!body) return;
  document.querySelectorAll('.wa-option').forEach(b=>b.disabled=true);
  const ub=document.createElement('div'); ub.className='wa-bubble user';
  ub.innerHTML=text+`<div class="wa-time">${getTime()}</div>`; body.appendChild(ub); body.scrollTop=body.scrollHeight;
  if(text.includes('Back to Home'))  { showPage('home'); return; }
  if(text.includes('View Services')) { showPage('services'); return; }
  if(LC.waStep===0) LC.waClaim=text;
  if(LC.waStep===3 && !waLeadSaved) {
    waLeadSaved=true;
    apiPost('/features/whatsapp-lead',{ phone:LC.user?.phone||'web-chat', claim_type:LC.waClaim, message_log:[{role:'user',text,ts:new Date().toISOString()}] })
      .catch(err=>console.warn('WA lead save failed:',err.message));
  }
  LC.waStep=Math.min(LC.waStep+1,Object.keys(WA_FLOWS).length-1);
  setTimeout(()=>renderWaMessage(),800);
}
function waSendInput() { const i=document.getElementById('waTextInput'); if(!i?.value.trim()) return; waSelectOption(i.value.trim()); i.value=''; }
function getTime() { const n=new Date(); return String(n.getHours()).padStart(2,'0')+':'+String(n.getMinutes()).padStart(2,'0'); }

// ── Feasibility Countdown ──────────────────────────────────────────────────
function startCountdown() {
  const due = LC.feasibilityDue || new Date(Date.now()+23*3600000+42*60000+18000);
  function tick() {
    const diff=Math.max(0,due-new Date());
    const h=Math.floor(diff/3600000), m=Math.floor((diff%3600000)/60000), s=Math.floor((diff%60000)/1000);
    ['cdHours','cdHours2'].forEach(id=>{const el=document.getElementById(id);if(el) el.textContent=String(h).padStart(2,'0');});
    ['cdMins','cdMins2'].forEach(id=>{const el=document.getElementById(id);if(el) el.textContent=String(m).padStart(2,'0');});
    ['cdSecs','cdSecs2'].forEach(id=>{const el=document.getElementById(id);if(el) el.textContent=String(s).padStart(2,'0');});
    if(diff>0) LC.countdown=setTimeout(tick,1000);
  }
  tick();
}

// ── Modal shortcuts ────────────────────────────────────────────────────────
function openSearchModal()  { openModal('searchModal');  }
function closeSearchModal() { closeModal('searchModal'); }

// ── Toast ──────────────────────────────────────────────────────────────────
function showToast(msg, type='success') {
  const colors={success:'var(--emerald)',error:'var(--rose)',warning:'var(--amber)'};
  const toast=document.createElement('div');
  toast.style.cssText=`position:fixed;bottom:100px;right:24px;z-index:9999;background:${colors[type]||colors.success};color:#fff;padding:14px 20px;border-radius:12px;font-size:0.875rem;box-shadow:0 8px 30px rgba(0,0,0,0.4);animation:fadeUp 0.3s ease both;max-width:320px;font-family:var(--ff-body);font-weight:500;line-height:1.4;`;
  toast.textContent=msg; document.body.appendChild(toast); setTimeout(()=>toast.remove(),4000);
}

// ── DOMContentLoaded ───────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', ()=>{
  initCertUpload(); initWhatsAppBot(); setTheme(LC.theme); triggerFadeIns();
  document.getElementById('waTextInput')?.addEventListener('keypress', e=>{ if(e.key==='Enter') waSendInput(); });
  ['fdInvestor','fdFather','fdGrandpa'].forEach(id=>{ document.getElementById(id)?.addEventListener('input',updateFamilyTree); });
  let sliderTimer;
  const slider=document.getElementById('sharesSlider');
  if(slider) slider.addEventListener('input',()=>{ clearTimeout(sliderTimer); sliderTimer=setTimeout(()=>updateEstimate(+slider.value),350); });
  ['high','medium','low'].forEach(l=>{ document.getElementById('prob-'+l)?.addEventListener('click',()=>updateProbability(l)); });
  updateProbability('high');
  if(LC.user?.name) document.querySelectorAll('.dash-greeting').forEach(el=>{ if(el.textContent.includes('Ravi')) el.textContent=el.textContent.replace('Ravi',LC.user.name.split(' ')[0]); });
  // Append error containers to forms that don't already have them
  injectErrorContainers();
});

// Inject error/success placeholder divs near submit buttons for forms
// that don't explicitly have them in the HTML
function injectErrorContainers() {
  const needs = [
    ['page-discovery',  'discoveryFormError',  'discoveryFormSuccess'],
    ['page-certificate','certUploadError',      null],
    ['page-family',     'familyFormError',      'familyFormSuccess'],
    ['page-partners',   'partnerFormError',     null],
    ['page-contact',    'contactSuccessError',  null],
    ['page-dashboard',  'dashboardLoadError',   null],
    ['page-admin',      'adminLoadError',       null],
  ];
  needs.forEach(([pageId, errId, succId]) => {
    const page = document.getElementById(pageId);
    if (!page) return;
    if (errId && !document.getElementById(errId)) {
      const div=document.createElement('div'); div.id=errId; div.style.display='none'; page.querySelector('form')?.appendChild(div)||page.appendChild(div);
    }
    if (succId && !document.getElementById(succId)) {
      const div=document.createElement('div'); div.id=succId; div.style.display='none'; page.querySelector('form')?.appendChild(div)||page.appendChild(div);
    }
  });
}
