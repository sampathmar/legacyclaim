/* ============================================================
   LegacyClaim — config.js
   Loaded before app.js on every page.

   On Vercel: frontend and API functions share the same domain,
   so we use a relative path — no hostname needed, no CORS.

   Locally: Vercel Dev (vercel dev) runs everything on one port
   too, so relative paths work there as well.
   For plain http-server local dev, the fallback hits localhost:3000.
   ============================================================ */

window.LC_CONFIG = {

  // ── Environment detection ──────────────────────────────────
  // true  → Vercel (production or preview) → relative /api/v1
  // false → plain local http-server        → localhost:3000/api/v1
  IS_VERCEL: (
    window.location.hostname !== 'localhost' &&
    window.location.hostname !== '127.0.0.1'
  ),

  // ── API Base URL ───────────────────────────────────────────
  get API_BASE_URL() {
    if (this.IS_VERCEL) {
      // Same origin — no hostname, no CORS, works on any Vercel domain
      return '/api/v1';
    }
    // Local development with plain static server
    return 'http://localhost:3000/api/v1';
  },

  // ── App metadata ───────────────────────────────────────────
  APP_NAME:    'Legacy Claim',
  APP_VERSION: '1.0.0',

};

// Shorthand read by app.js
window.LC_API = window.LC_CONFIG.API_BASE_URL;

console.info(
  `[LegacyClaim] API → ${window.LC_CONFIG.API_BASE_URL}`,
  window.LC_CONFIG.IS_VERCEL ? '(Vercel — same origin)' : '(local dev — localhost:3000)'
);
