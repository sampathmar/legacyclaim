// api/v1/features/[...path].js
// Catch-all Vercel Function that handles ALL /api/v1/features/* routes.
// This is necessary because features has nested paths:
//   /estimate               (public GET)
//   /whatsapp-lead          (public POST)
//   /certificate/upload     (POST, auth)
//   /family-discovery       (POST, auth)
//   /cases/:id/fast-track   (POST, auth)
//   /cases/:id/nri          (POST, auth)
//   /cases/:id/probability  (GET,  auth)
//   /cases/:id/feasibility  (GET/PATCH, auth)
'use strict';
const express   = require('express');
const { body }  = require('express-validator');
const createApp = require('../../../lib/createApp');
const validate  = require('../../../lib/middleware/validate');
const upload    = require('../../../lib/middleware/upload');
const { authenticate, requireStaff } = require('../../../lib/middleware/auth');
const {
  uploadCertificate,
  familyDiscovery,
  setFastTrack,
  setNriDetails,
  getProbability,
  getValueEstimate,
  whatsappLead,
  getFeasibility,
  updateFeasibility,
} = require('../../../lib/controllers/featuresController');

const app    = createApp();
const router = express.Router();

// Public endpoints
router.get('/estimate',       getValueEstimate);
router.post('/whatsapp-lead', whatsappLead);

// Auth-required endpoints
router.post('/certificate/upload',    authenticate, upload.single('certificate'), uploadCertificate);
router.post('/family-discovery',      authenticate,
  validate([body('investor_name').notEmpty().withMessage('investor_name required.')]),
  familyDiscovery
);
router.post('/cases/:id/fast-track',  authenticate, setFastTrack);
router.post('/cases/:id/nri',         authenticate, setNriDetails);
router.get('/cases/:id/probability',  authenticate, getProbability);
router.get('/cases/:id/feasibility',  authenticate, getFeasibility);
router.patch('/cases/:id/feasibility',authenticate, requireStaff, updateFeasibility);

app.use('/', router);
app._finaliseMiddleware();

module.exports = app;
