// api/v1/dashboard.js
// Handles: GET /client, GET /stats (admin), GET /workload, GET /revenue
'use strict';
const express   = require('express');
const createApp = require('../../lib/createApp');
const { authenticate, requireAdmin, requireStaff } = require('../../lib/middleware/auth');
const {
  getAdminStats, getClientDashboard, getStaffWorkload, getRevenueReport,
} = require('../../lib/controllers/dashboardController');

const app    = createApp();
const router = express.Router();

router.get('/client',   authenticate, getClientDashboard);
router.get('/stats',    authenticate, requireStaff,  getAdminStats);
router.get('/workload', authenticate, requireAdmin, getStaffWorkload);
router.get('/revenue',  authenticate, requireAdmin, getRevenueReport);

// Also support GET / → client dashboard (used by frontend's loadDashboardStats)
router.get('/', authenticate, getClientDashboard);

// Support GET /admin → admin stats (used by frontend's loadAdminStats)
router.get('/admin', authenticate, requireStaff, getAdminStats);

app.use('/', router);
app._finaliseMiddleware();

module.exports = app;
