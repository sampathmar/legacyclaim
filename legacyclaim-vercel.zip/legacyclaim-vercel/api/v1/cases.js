// api/v1/cases.js
// Handles all case CRUD routes
'use strict';
const express   = require('express');
const { body }  = require('express-validator');
const createApp = require('../../lib/createApp');
const validate  = require('../../lib/middleware/validate');
const { authenticate, requireAdmin, requireStaff } = require('../../lib/middleware/auth');
const {
  createCase, getCases, getCaseById, updateStatus,
  assignCase, getClientCases, updateCase, deleteCase,
} = require('../../lib/controllers/casesController');

const app    = createApp();
const router = express.Router();

const CLAIM_TYPES = ['physical_shares','iepf','dividends','pf','insurance','bank_deposit','bonds','mutual_fund','legal_heir','nri_claim'];
const CASE_STATUSES = ['new_lead','under_review','docs_pending','docs_received','filed','under_process','query_raised','approved','recovered','closed'];

const createCaseRules = [
  body('claim_type').isIn(CLAIM_TYPES).withMessage(`claim_type must be one of: ${CLAIM_TYPES.join(', ')}`),
  body('client_id').optional().isUUID(),
  body('estimated_value').optional().isFloat({ min: 0 }),
  body('priority').optional().isIn(['low','normal','high','urgent']),
];
const updateStatusRules = [
  body('status').isIn(CASE_STATUSES).withMessage(`status must be one of: ${CASE_STATUSES.join(', ')}`),
  body('notes').optional().isString().isLength({ max: 1000 }),
];
const assignRules = [
  body('staff_id').isUUID().withMessage('staff_id must be a valid UUID.'),
];

router.get('/my-cases',    authenticate, getClientCases);
router.post('/',           authenticate, validate(createCaseRules), createCase);
router.get('/:id',         authenticate, getCaseById);
router.get('/',            authenticate, requireStaff, getCases);
router.put('/:id',         authenticate, requireStaff, updateCase);
router.post('/:id/status', authenticate, requireStaff, validate(updateStatusRules), updateStatus);
router.post('/:id/assign', authenticate, requireStaff, validate(assignRules), assignCase);
router.delete('/:id',      authenticate, requireAdmin, deleteCase);

app.use('/', router);
app._finaliseMiddleware();

module.exports = app;
