// api/v1/messages.js
'use strict';
const express   = require('express');
const { body }  = require('express-validator');
const createApp = require('../../lib/createApp');
const validate  = require('../../lib/middleware/validate');
const { authenticate } = require('../../lib/middleware/auth');
const { sendMessage, getCaseMessages, getInbox, markRead } = require('../../lib/controllers/messagesController');

const app    = createApp();
const router = express.Router();

const messageRules = [
  body('body').trim().notEmpty().withMessage('Message body is required.').isLength({ max: 5000 }),
  body('subject').optional().isString().isLength({ max: 500 }),
];

router.get('/inbox',              authenticate, getInbox);
router.post('/',                  authenticate, validate(messageRules), sendMessage);
router.get('/case/:case_id',      authenticate, getCaseMessages);
router.patch('/:message_id/read', authenticate, markRead);

app.use('/', router);
app._finaliseMiddleware();

module.exports = app;
