// api/v1/discovery.js
// Handles: POST /  (submit scan), GET /:id (poll report)
//          GET /   (list — staff), POST /convert (staff)
'use strict';
const express   = require('express');
const { body }  = require('express-validator');
const createApp = require('../../lib/createApp');
const validate  = require('../../lib/middleware/validate');
const upload    = require('../../lib/middleware/upload');
const { authenticate, requireStaff } = require('../../lib/middleware/auth');
const {
  submitDiscovery, getReport, listReports, convertReportToCase,
} = require('../../lib/controllers/discoveryController');

const app    = createApp();
const router = express.Router();

const discoveryRules = [
  body('name').trim().notEmpty().withMessage('Name is required.'),
  body('mobile').trim().notEmpty().withMessage('Mobile number is required.'),
  body('pan').optional().isLength({ min: 10, max: 10 }).withMessage('PAN must be 10 characters.'),
];

// Public
router.post('/',        upload.single('pan_doc'), validate(discoveryRules), submitDiscovery);
router.get('/:id',      getReport);
// Staff/Admin
router.get('/',         authenticate, requireStaff, listReports);
router.post('/convert', authenticate, requireStaff, convertReportToCase);

app.use('/', router);
app._finaliseMiddleware();

module.exports = app;
