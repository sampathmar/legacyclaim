// api/v1/partners.js
// Handles: POST / (public signup), GET / (admin list),
//          GET /:partner_id (dashboard), PATCH /:id/status (admin)
'use strict';
const express   = require('express');
const { body }  = require('express-validator');
const createApp = require('../../lib/createApp');
const validate  = require('../../lib/middleware/validate');
const { authenticate, requireAdmin } = require('../../lib/middleware/auth');
const {
  registerPartner, getPartnerDashboard, listPartners, updatePartnerStatus,
} = require('../../lib/controllers/partnersController');

const app    = createApp();
const router = express.Router();

const partnerRules = [
  body('name').trim().notEmpty().withMessage('Name is required.'),
  body('email').isEmail().withMessage('Valid email required.').normalizeEmail(),
  body('phone').trim().notEmpty().withMessage('Phone is required.'),
  body('partner_type').isIn(['ca','lawyer','broker','bank_agent','other']).withMessage('Invalid partner type.'),
];

router.post('/',              validate(partnerRules), registerPartner);
router.get('/',               authenticate, requireAdmin, listPartners);
router.get('/:partner_id',    authenticate, getPartnerDashboard);
router.patch('/:id/status',   authenticate, requireAdmin,
  validate([body('status').isIn(['pending','active','suspended'])]),
  updatePartnerStatus
);

app.use('/', router);
app._finaliseMiddleware();

module.exports = app;
