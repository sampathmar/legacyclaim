// api/v1/invoices.js
'use strict';
const express   = require('express');
const { body }  = require('express-validator');
const createApp = require('../../lib/createApp');
const validate  = require('../../lib/middleware/validate');
const { authenticate, requireStaff, requireAdmin } = require('../../lib/middleware/auth');
const { createInvoice, getInvoices, getInvoiceById, markPaid } = require('../../lib/controllers/invoicesController');

const app    = createApp();
const router = express.Router();

const invoiceRules = [
  body('case_id').notEmpty().withMessage('case_id is required.'),
  body('recovery_amount').isFloat({ min: 1 }).withMessage('recovery_amount must be a positive number.'),
];

router.get('/',          authenticate, getInvoices);
router.get('/:id',       authenticate, getInvoiceById);
router.post('/',         authenticate, requireStaff, validate(invoiceRules), createInvoice);
router.patch('/:id/pay', authenticate, requireAdmin, markPaid);

app.use('/', router);
app._finaliseMiddleware();

module.exports = app;
