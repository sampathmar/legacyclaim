// api/v1/auth.js
// Handles: POST /login, POST /register, POST /refresh, GET /me,
//          PUT /password, GET /users, PATCH /users/:userId/status
'use strict';
const express    = require('express');
const { body }   = require('express-validator');
const createApp  = require('../../lib/createApp');
const validate   = require('../../lib/middleware/validate');
const { authenticate, requireAdmin, optionalAuth } = require('../../lib/middleware/auth');
const {
  register, login, refresh, getMe,
  changePassword, listUsers, toggleUserStatus,
} = require('../../lib/controllers/authController');

const app    = createApp();
const router = express.Router();

const registerRules = [
  body('name').trim().notEmpty().withMessage('Name is required.').isLength({ max: 255 }),
  body('email').isEmail().withMessage('Valid email is required.').normalizeEmail(),
  body('password')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters.')
    .matches(/[A-Z]/).withMessage('Must contain at least one uppercase letter.')
    .matches(/[0-9]/).withMessage('Must contain at least one number.'),
  body('phone').optional().isMobilePhone().withMessage('Valid phone number required.'),
  body('role').optional().isIn(['admin','staff','client']).withMessage('Invalid role.'),
];
const loginRules = [
  body('email').isEmail().withMessage('Valid email required.').normalizeEmail(),
  body('password').notEmpty().withMessage('Password is required.'),
];
const changePasswordRules = [
  body('currentPassword').notEmpty().withMessage('Current password is required.'),
  body('newPassword')
    .isLength({ min: 8 }).withMessage('New password must be at least 8 characters.')
    .matches(/[A-Z]/).withMessage('Must contain at least one uppercase letter.')
    .matches(/[0-9]/).withMessage('Must contain at least one number.'),
];

router.post('/register', optionalAuth, validate(registerRules), register);
router.post('/login',    validate(loginRules), login);
router.post('/refresh',  refresh);
router.get('/me',        authenticate, getMe);
router.put('/password',  authenticate, validate(changePasswordRules), changePassword);
router.get('/users',     authenticate, requireAdmin, listUsers);
router.patch('/users/:userId/status', authenticate, requireAdmin, toggleUserStatus);

app.use('/', router);
app._finaliseMiddleware();

module.exports = app;
