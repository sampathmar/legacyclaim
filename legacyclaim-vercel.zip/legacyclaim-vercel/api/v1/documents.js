// api/v1/documents.js
// Handles file upload + document management
'use strict';
const express   = require('express');
const createApp = require('../../lib/createApp');
const upload    = require('../../lib/middleware/upload');
const { authenticate, requireStaff, requireAdmin } = require('../../lib/middleware/auth');
const {
  uploadDocument, uploadMultipleDocuments, getCaseDocuments,
  verifyDocument, getDocumentUrl, deleteDocument,
} = require('../../lib/controllers/documentsController');

const app    = createApp();
const router = express.Router();

router.post('/upload',          authenticate, upload.single('file'),       uploadDocument);
router.post('/upload-multiple', authenticate, upload.array('files', 5),    uploadMultipleDocuments);
router.get('/case/:case_id',    authenticate, getCaseDocuments);
router.get('/:doc_id/url',      authenticate, getDocumentUrl);
router.patch('/:doc_id/verify', authenticate, requireStaff, verifyDocument);
router.delete('/:doc_id',       authenticate, requireAdmin, deleteDocument);

app.use('/', router);
app._finaliseMiddleware();

module.exports = app;
