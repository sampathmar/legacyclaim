// api/health.js
// Health check — Vercel Function at GET /api/health
// Used to verify deployment is alive (no auth required)
'use strict';
module.exports = (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.status(200).json({
    status:      'ok',
    service:     'LegacyClaim API',
    version:     'v1',
    environment: process.env.NODE_ENV || 'production',
    timestamp:   new Date().toISOString(),
  });
};
