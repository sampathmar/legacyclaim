Place your logo.png in this folder
